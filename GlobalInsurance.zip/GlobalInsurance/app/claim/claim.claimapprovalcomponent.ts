import {Component} from "@angular/core";


@Component({
    selector:'claim-approval',
    templateUrl:'./app/claim/claim.claimapproval.component.html',
    styleUrls:['./app/claim/claim.claimapproval.component.css']

})
export class ClaimApprovalComponent
{



}