import {Component} from "@angular/core";

@Component({
        selector:'gic-home',
        templateUrl:'./app/app.component.html',
        styleUrls:['./app/app.component.css']
})
export class AppComponent
{
  private imgPath:string;
  private address:string;


  constructor()
  {
      this.imgPath="./images/gic.jpg";
      this.address="./images/gicaddress.png";
  }


}