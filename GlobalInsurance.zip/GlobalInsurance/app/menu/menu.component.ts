import {Component, OnInit} from "@angular/core";
import {MenuService} from "../services/menuservice";
@Component({
    selector:'claim-menu',
    templateUrl:'./app/menu/menu.component.html',
    styleUrls:['./app/menu/menu.component.css']
})
export class MenuComponent implements OnInit
{
    private menu:any;
    constructor(private menuServiceObj:MenuService)
    {

    }
    ngOnInit()
    {
      this.menu=this.menuServiceObj.getMenuData();
    }
}