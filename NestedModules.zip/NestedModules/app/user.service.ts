import { Injectable } from '@angular/core';
import {Http} from '@angular/http'
import 'rxjs'
@Injectable()
/** Dummy version of an authenticated user service */
export class UserService {
  userName = 'Parameswari';
  private http;
  constructor(httpObj:Http)
  {
   this.http=httpObj;
  }
  getUserData()
  {

    return this.http.get("https://jsonplaceholder.typicode.com/users")
        .flatMap((data)=>data.json())

  }


}

