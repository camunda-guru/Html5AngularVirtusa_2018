import { NgModule }           from '@angular/core';
import { BrowserModule }      from '@angular/platform-browser';
import {HttpModule} from "@angular/http";
import {NameCaseConversion} from './title.pipe';

/* App Root */
import    { AppComponent }       from './app.component';
/*
       { AppComponent }       from './app.component';
*/
import { HighlightDirective } from './highlight.directive';
import { TitleComponent }     from './title.component';
import { UserService }        from './user.service';

/* Contact Imports */
import   { ContactModule }      from './contact/contact.module';
/*
       { ContactModule }      from './contact/contact.module';
*/

@NgModule({
  imports:      [ BrowserModule, ContactModule,HttpModule ],
  declarations: [ AppComponent, HighlightDirective, TitleComponent,NameCaseConversion ],
  providers:    [ UserService ],
  bootstrap:    [ AppComponent ],
})
export class AppModule { }


