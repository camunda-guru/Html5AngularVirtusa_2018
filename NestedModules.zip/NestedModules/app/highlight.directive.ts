import { Directive, ElementRef } from '@angular/core';

@Directive({ selector: '[highlight]' })
/** Highlight the attached element in gold */
export class HighlightDirective {
  constructor(el: ElementRef) {
   // el.nativeElement.style.backgroundColor = 'gold';
    console.log(
      `* AppRoot highlight called for ${el.nativeElement.tagName}`);

      console.log(el.nativeElement.nodeName);
      if(el.nativeElement.nodeName==='H1')
          el.nativeElement.className="title";
      if(el.nativeElement.nodeName==='P')
          el.nativeElement.style.backgroundColor="blue";
  }
}

