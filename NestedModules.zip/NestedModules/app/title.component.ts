import { Component, Input ,OnInit} from '@angular/core';
import { UserService } from './user.service';

@Component({
  selector: 'app-title',
  templateUrl: './app/title.component.html',
  styleUrls:['./app/title.component.css']
})
export class TitleComponent implements OnInit{
  @Input() subtitle = '';
  title = 'Citi, Chennai';
  user = '';
  userArr:any=[];
  private userService;
  constructor(private userServiceObj:UserService) {

  }
  ngOnInit()
  {
   this.userServiceObj.getUserData().subscribe(response=>{
    this.userArr.push(response);

   })
  }
}

