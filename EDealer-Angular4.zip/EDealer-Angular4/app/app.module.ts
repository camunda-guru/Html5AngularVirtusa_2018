import {NgModule} from '@angular/core'
import {BrowserModule} from '@angular/platform-browser'
import { CommonModule } from '@angular/common';
import { AppComponent } from './app.component';
import {MenuComponent} from "./menu/menu.component";
import {MenuService} from "./service/menuservice";
import {

    MatAutocompleteModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDatepickerModule,
    MatDialogModule,
    MatExpansionModule, MatFormField,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatSortModule,
    MatStepperModule,
    MatTableModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,
} from '@angular/material';
import {AppRoutingModule} from "./app.routing.module";
import {SpotComponent} from "./spot/spot.component";
import {ForwardComponent} from "./forward/forward.component";
import {NdfComponent} from "./ndf/ndf.component";
import {SwapComponent} from "./swap/swap.component";
import {NdfswapComponent} from "./ndfswap/ndfswap.component";
@NgModule({
    imports:[BrowserModule,CommonModule, MatButtonModule,AppRoutingModule],
    declarations:[AppComponent,MenuComponent,SpotComponent,ForwardComponent,NdfComponent,SwapComponent,NdfswapComponent],
    providers:[MenuService],
    bootstrap:[AppComponent]
})

export class AppModule
{

}