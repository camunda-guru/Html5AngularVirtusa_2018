import {Component} from "@angular/core";


@Component({
    selector:'spot',
    templateUrl:'./app/spot/spot.component.html',
    styleUrls:['./app/spot/spot.component.css']
})
export class SpotComponent
{

}