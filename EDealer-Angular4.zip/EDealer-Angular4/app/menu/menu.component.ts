import {Component, OnInit} from '@angular/core'
import {MenuService} from "../service/menuservice";

@Component({
    selector:'edealer-menu',
    templateUrl:'./app/menu/menu.component.html',
    styleUrls:['./app/menu/menu.component.css']

})
export class MenuComponent implements OnInit
{
   private menu:any;
   constructor(private serviceObj:MenuService)
   {

   }

   ngOnInit()
   {
       this.menu=this.serviceObj.getMenuData();
   }
}