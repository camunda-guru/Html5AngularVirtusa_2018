import {Component} from "@angular/core"

@Component({
    selector:'edealer-app',
    templateUrl:'./app/app.component.html',
    styleUrls:['./app/app.component.css']
})
export class AppComponent
{

    private logo:string;
    private banner:string;
    constructor()
    {
        this.logo="./app/resources/logo.png";
        this.banner="./app/resources/banner.jpg";
    }

}