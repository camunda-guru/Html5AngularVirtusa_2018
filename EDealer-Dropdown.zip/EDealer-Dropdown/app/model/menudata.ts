import {MenuItem} from "./menuitem";

export var menuData:MenuItem[]=[
new MenuItem(1,"Spot"),
    new MenuItem(2,"Forward"),
    new MenuItem(3,"Swap"),
    new MenuItem(4,"NDF"),
    new MenuItem(5,"NDF Swap"),
    new MenuItem(6,"Branch")
]