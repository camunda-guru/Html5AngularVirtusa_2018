import {Component} from "@angular/core";


@Component({
    selector:'ndf-swap',
    templateUrl:'./app/ndfswap/ndfswap.component.html',
    styleUrls:['./app/ndfswap/ndfswap.component.css']
})
export class NdfswapComponent
{

}