import {Component} from "@angular/core";


@Component({
    selector:'ndf',
    templateUrl:'./app/ndf/ndf.component.html',
    styleUrls:['./app/ndf/ndf.component.css']
})
export class NdfComponent
{

}