import {Component} from "@angular/core";


@Component({
    selector:'swap',
    templateUrl:'./app/swap/swap.component.html',
    styleUrls:['./app/swap/swap.component.css']
})
export class SwapComponent
{

}