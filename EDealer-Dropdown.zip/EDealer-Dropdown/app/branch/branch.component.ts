import {Component, OnInit} from "@angular/core";
import {CountryService} from "../service/countryService";
import {State} from "../model/state";
import {Observable,} from "rxjs/Observable";
import {DataService} from "../service/dataservice";

@Component({
    selector:'branch',
    templateUrl:'./app/branch/branch.component.html',
    styleUrls:['./app/branch/branch.component.css']
})
export class BranchComponent implements OnInit
{
    private countries:any=[];
    private selectedCountry:String="";
    statesArr: State[];
    constructor(private countryServiceObj:CountryService,private _dataService: DataService)
   {

   }


   ngOnInit()
   {

       this.countryServiceObj.getCountryNames().subscribe(response=>{
           this.countries.push(response);
       })


   }
    onSelect(obj)
   {
       console.log(obj.value.name);

       this.statesArr = this._dataService.getStates().filter((item)=>
           item.countryid == obj.value.callingCodes);
       console.log(this.statesArr);

   }


}