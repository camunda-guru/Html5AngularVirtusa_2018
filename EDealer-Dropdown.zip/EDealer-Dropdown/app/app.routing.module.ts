import {NgModule} from "@angular/core";
import {Routes, RouterModule} from "@angular/router";
import {SpotComponent} from "./spot/spot.component";
import {ForwardComponent} from "./forward/forward.component";
import {NdfComponent} from "./ndf/ndf.component";
import {NdfswapComponent} from "./ndfswap/ndfswap.component";
import {SwapComponent} from "./swap/swap.component";
import {BranchComponent} from "./branch/branch.component";


const routes:Routes=[{
    path: 'Spot',
    component: SpotComponent
},
    {
        path: 'Swap',
        component: SwapComponent
    },
    {
        path: 'Forward',
        component: ForwardComponent
    },
    {
        path: 'NDF',
        component: NdfComponent
    },

    {
        path: 'NDF Swap',
        component: NdfswapComponent
    },

    {
        path: 'Branch',
        component: BranchComponent
    }
];

@NgModule({
    imports:[RouterModule.forRoot(routes)],
    exports:[RouterModule]
})
export class AppRoutingModule
{
}
