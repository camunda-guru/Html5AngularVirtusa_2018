import {NgModule} from '@angular/core'
import {BrowserModule} from '@angular/platform-browser'
import { CommonModule } from '@angular/common';
import { AppComponent } from './app.component';
import {MenuComponent} from "./menu/menu.component";
import {MenuService} from "./service/menuservice";
import {

    MatAutocompleteModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDatepickerModule,
    MatDialogModule,
    MatExpansionModule,  MatFormFieldModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatSortModule,
    MatStepperModule,
    MatTableModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,
} from '@angular/material';
import {AppRoutingModule} from "./app.routing.module";
import {SpotComponent} from "./spot/spot.component";
import {ForwardComponent} from "./forward/forward.component";
import {NdfComponent} from "./ndf/ndf.component";
import {SwapComponent} from "./swap/swap.component";
import {NdfswapComponent} from "./ndfswap/ndfswap.component";
import {BranchComponent} from "./branch/branch.component";
import {CountryService} from "./service/countryService";
import {HttpModule} from "@angular/http";
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";
import {DataService} from "./service/dataservice";
@NgModule({
    imports:[BrowserModule,CommonModule, MatButtonModule,MatSelectModule,MatInputModule,MatAutocompleteModule, MatFormFieldModule,AppRoutingModule,HttpModule,BrowserAnimationsModule],
    declarations:[AppComponent,MenuComponent,SpotComponent,ForwardComponent,NdfComponent,SwapComponent,NdfswapComponent,BranchComponent],
    providers:[MenuService,CountryService,DataService],
    bootstrap:[AppComponent]
})

export class AppModule
{

}