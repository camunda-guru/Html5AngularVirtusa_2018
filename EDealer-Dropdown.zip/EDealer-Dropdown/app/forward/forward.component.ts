import {Component} from "@angular/core";


@Component({
    selector:'forward',
    templateUrl:'./app/forward/forward.component.html',
    styleUrls:['./app/forward/forward.component.css']
})
export class ForwardComponent
{

}