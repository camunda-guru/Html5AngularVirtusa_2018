import {Injectable} from "@angular/core";
import {MenuItem} from "../model/menuitem";
import {menuData} from "../model/menudata";

@Injectable()
export class MenuService
{

    getMenuData():MenuItem[]
    {
        return menuData;
    }

}