/**
 * Created by BALASUBRAMANIAM on 04-01-2017.
 */
import { NgModule } from '@angular/core';
import { BrowserModule }  from '@angular/platform-browser';

import { AppComponent } from './app.component';

import { CounterComponent } from './counter.component';

@NgModule({
    imports: [BrowserModule],
    declarations: [
        AppComponent,
        CounterComponent
    ],
    exports: [AppComponent],
    bootstrap: [AppComponent]
})
export class AppModule {
}
