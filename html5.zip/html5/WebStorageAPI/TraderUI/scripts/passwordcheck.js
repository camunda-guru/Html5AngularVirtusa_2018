function display(data)
{
	var RE_NAME = /^[a-zA-Z]*$/;
     
    if(RE_NAME.test(data.value) )
    	alert("valid Data");
    else
    	alert("Invalid Data");

}

function RetPhoto()
{
	if(window.localStorage.getItem("ProfilePhoto")!=undefined)
	{
	    console.log("image available");
	    var img = new Image();

	    img.onload=function(evt)
	    {
	        var photoref=document.getElementById("myphoto");
	        photoref.appendChild(img);

	    }

	    img.src=window.localStorage.getItem("ProfilePhoto");


	}





}




function GetData()
{
 name=document.getElementById("customername").value;
	
 console.log("Your Name" + name);
 
 address=document.getElementById("address").value;
	
 console.log("Your Address is" + address);
 
 dob=document.getElementById("dob").value;
	
 console.log("Your DOB" + dob);
 
 phoneno=document.getElementById("phoneno").value;
	
 console.log("Your Phone Number" + phoneno);
 
 email=document.getElementById("email").value;
	
 console.log("Your Email" + email);
 
 photoref=document.getElementById("photo");
 
 filetype=/image.*/;
 if(photoref.files[0].type.match(filetype))
	 {
	 console.log("file type matching");
     var reader = new FileReader();
     reader.onload=function(evt)
     {
         window.localStorage.setItem
         ("ProfilePhoto",reader.result);
         console.log("file saved");

     };

     reader.readAsDataURL(photoref.files[0]);
	 }
  

}