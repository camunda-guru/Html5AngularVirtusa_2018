/**
 * Created by BALASUBRAMANIAM on 15-09-2015.
 */
//console.log("Called");

//create JSON Data



var quizlist ='[ {'+
    '"Question":     "What is the full form of HTML?",'+
    '"Answers":'+
    '['+
    '{"key":"Hyper Text Mark Up Language"},'+
    '{"key":"Hydro Text Mark Up Language"},'+
    '{"key":"Hyper Text Made Up of Java Language"}'+
    '],'+
    '"CorrectAnswer":"1"'+

    '}, {'+
    '"Question":     "What is Android?",'+
    '"Answers":'+
    '['+
    '{"key":"OS"},'+
    '{"key":"App"},'+
    '{"key":"Website"}'+
    '],'+
    '"CorrectAnswer":"1"'+

    '},{'+
    '"Question":     "Why do we need cordova framework?",'+
    '"Answers":'+
    '['+
    '{"key":"OS"},'+
    '{"key":"Hybrid App"},'+
    '{"key":"Native App"}'+
    '],'+
    '"CorrectAnswer":"2"'+

    '} ,{'+
    '"Question":     "Why do we need Spring framework?",'+
    '"Answers":'+
    '['+
    '{"key":"EJB Replacement"},'+
    '{"key":"AOP"},'+
    '{"key":"more modules and DI"}'+
    '],'+
    '"CorrectAnswer":"3"'+

    '} ]';

//convert JSON to javascript object
//use parse method


var quizobj = JSON.parse(quizlist);


function initialize()
{
   //console.log(window.localStorage.getItem("quizlist"))
    var sectionref= document.getElementById("quiz");

        i=0;
    //for(var ques in quizobj) {
        console.log(quizobj[i].Question);
        //console.log(quizobj[ques].Answers.length);
        breaknode=document.createElement("br");
        paranode=document.createElement("p");
        textnode=document.createTextNode(quizobj[i].Question);
        paranode.appendChild(textnode);
        paranode.appendChild(breaknode);
        sectionref.appendChild(paranode);
        j=1;
        for(var ans in quizobj[0].Answers)
        {
            breaknode=document.createElement("br");
            textnode=document.createTextNode(quizobj[i].Answers[ans].key);
            inputnode=document.createElement("input");
            inputnode.setAttribute("type","radio")

            inputnode.setAttribute("name","radiogroup");
            inputnode.setAttribute("value",j);
            paranode.appendChild(inputnode);
            paranode.appendChild(textnode);
            paranode.appendChild(breaknode);
            console.log(quizobj[i].Answers[ans].key);
            j++;
        }

        console.log(quizobj[i].CorrectAnswer);
    i++;
        buttonnode=document.createElement("button");
         textnode=document.createTextNode("Next");
        buttonnode.appendChild(textnode);
        buttonnode.setAttribute("onclick", "test(i)");
         sectionref.appendChild(buttonnode);

    //}
}

window.onload=initialize;

function test(i)
{
    var radios = document.getElementsByName('radiogroup');

    for (var r = 0, length = radios.length; r < length; r++) {
        if (radios[r].checked) {
            // do whatever you want with the checked radio
            console.log("Selected Answer"+radios[r].value);
            if(radios[r].value==quizobj[i-1].CorrectAnswer) {
                console.log("correct answer");
                window.sessionStorage.setItem(i,radios[r].value);
            }
            // only one radio can be logically checked, don't check the rest
            break;
        }
    }
        var sectionref= document.getElementById("quiz");
    while(sectionref.hasChildNodes())
      sectionref.removeChild(sectionref.firstChild);


    console.log(quizobj[i].Question);
    //console.log(quizobj[ques].Answers.length);
    breaknode=document.createElement("br");
    paranode=document.createElement("p");
    textnode=document.createTextNode(quizobj[i].Question);
    paranode.appendChild(textnode);
    paranode.appendChild(breaknode);
    sectionref.appendChild(paranode);
    j=1;
    for(var ans in quizobj[0].Answers)
    {
        breaknode=document.createElement("br");
        textnode=document.createTextNode(quizobj[i].Answers[ans].key);
        inputnode=document.createElement("input");
        inputnode.setAttribute("type","radio")
        inputnode.setAttribute("name","radiogroup");
        inputnode.setAttribute("value",j);
        paranode.appendChild(inputnode);
        paranode.appendChild(textnode);
        paranode.appendChild(breaknode);
        console.log(quizobj[i].Answers[ans].key);
        j++;
    }

    console.log(quizobj[i].CorrectAnswer);
    k=i+1;
  //alert("k value"+k);
    buttonnode=document.createElement("button");
    if(k!=quizobj.length)
     textnode=document.createTextNode("Next");
    else
        textnode=document.createTextNode("Finish");
    buttonnode.appendChild(textnode);
    buttonnode.setAttribute("onclick", "test(k)");
    sectionref.appendChild(buttonnode);
}

/*
*/
// read the properties from javascript object


/*

function initialize()
{


    var divref = document.getElementById("RestaurantData");

    var headingelem = document.createElement("h1");
    var heading = document.createTextNode(restaurantobj.Organization);
    headingelem.appendChild(heading);
    divref.appendChild(headingelem);

    var tableelem = document.createElement('table');
    //var atrribute = document.createAttribute("border");
    tableelem.setAttribute("border", 1);
    for(var res in restaurantobj.Restaurants)
    {
        var rowelem = document.createElement('tr');
        var tdelem = document.createElement('td');
        var textnode = document.createTextNode(restaurantobj.Restaurants[res].Name);
        tdelem.appendChild(textnode);
        rowelem.appendChild(tdelem);
        tdelem = document.createElement('td');
        textnode = document.createTextNode(restaurantobj.Restaurants[res].Address);
        tdelem.appendChild(textnode);
        rowelem.appendChild(tdelem);
        tdelem = document.createElement('td');
        textnode = document.createTextNode(restaurantobj.Restaurants[res].type);
        tdelem.appendChild(textnode);
        rowelem.appendChild(tdelem);
        tableelem .appendChild(rowelem);

        //object->arrayname->position->propertyname
        //console.log(restaurantobj.Restaurants[res].Name);
        //console.log(restaurantobj.Restaurants[res].Address);
        //console.log(restaurantobj.Restaurants[res].type);
    }

    divref.appendChild(tableelem);
}


window.onload=initialize;

*/