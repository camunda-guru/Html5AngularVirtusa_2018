/**
 * Created by BALASUBRAMANIAM on 07-01-2015.
 */

function AddQty()
{
    var resultarea= document.getElementById("result");

    if(localStorage.getItem("cartqty")==undefined)
    {
        localStorage.setItem("cartqty",1);

    }
    else
    {
        data=parseInt(localStorage.getItem("cartqty"))+1;
        localStorage.setItem("cartqty",data);
    }
    resultarea.innerText=localStorage.getItem("cartqty");


}
function SubQty()
{
    var resultarea= document.getElementById("result");


        data=parseInt(localStorage.getItem("cartqty"))-1;
        localStorage.setItem("cartqty",data);

    resultarea.innerText=localStorage.getItem("cartqty");


}
