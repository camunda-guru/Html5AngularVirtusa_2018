/**
 * Created by BALASUBRAMANIAM on 16-09-2015.
 */


var jsonarr=[];
function ReadData()
{

    var objectStore = db.transaction("QuizData").
        objectStore("QuizData");

    objectStore.openCursor().onsuccess = function(event) {
        var cursor = event.target.result;
        if (cursor) {
            console.log(JSON.stringify(event.target.result.value));
            jsonarr.push(JSON.stringify(event.target.result.value));
            window.localStorage.setItem("quizlist1",jsonarr);
            //console.log("Question id " + cursor.key + " is " +
            //cursor.value.Question+cursor.value.Answer1+cursor.value.Answer2+cursor.value.Answer3+cursor.value.CorrectAnswer);
            cursor.continue();
        }
        else {
            console.log("No more entries!");
        }
    };




}


function ReadSpecQuestion()
{
    var transaction = db.transaction(["QuizData"]);
    var objectStore = transaction.objectStore("QuizData");
    var data = document.getElementById("questionno");
    console.log(data.value);
    var request = objectStore.get(data.value);
    request.onerror = function(event) {
        alert("Unable to retrieve data from database!");
    };
    request.onsuccess = function(event) {
        // Do something with the request.result!
        //console.log(request);
        if(request.result) {
            console.log("Question id " + request.result.QuestionNo + " is " + request.result.Question+request.result.Answer1);
        } else {
            console.log("No more entries!");
        }
    };




}