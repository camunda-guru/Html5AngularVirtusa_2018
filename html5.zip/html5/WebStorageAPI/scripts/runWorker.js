/**
 * Created by BALASUBRAMANIAM on 07-01-2015.
 */
var msg = 'I am virus!';
var n = 1;
while (true) {
    postMessage(msg);

    msg =  'I am virus! Eating!' + ' ' + ++n + 'bytes' ;
}
