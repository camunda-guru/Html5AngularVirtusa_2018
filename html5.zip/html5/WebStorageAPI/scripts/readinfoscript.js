/**
 * Created by BALASUBRAMANIAM on 07-01-2015.
 */

var dbref = window.indexedDB.open("CustomerDB",1);
var db;
dbref.onerror = function(evt)
{
    console.log("Error Message"+evt.target.error);

};

dbref.onsuccess = function(evt)
{
    db = dbref.result;
    console.log("Database Opened");


};

dbref.onupgradeneeded=function(evt)
{
    db = evt.target.result;
    var objectStore = db.createObjectStore("Profiles", {keyPath: "CustomerID"});
    console.log("Object Store Opened");

};


function ReadData() {
    var transaction = db.transaction(["Profiles"]);
    var objectStore = transaction.objectStore("Profiles");
    var data = document.getElementById("custid");
    console.log(data.value);
    var request = objectStore.get(parseInt(data.value));
    request.onerror = function(event) {
        alert("Unable to retrieve daa from database!");
    };
    request.onsuccess = function(event) {
        // Do something with the request.result!
        //console.log(request);
        if(request.result) {
            console.log("Name for id " + request.result.CustomerID + " is " + request.result.Name+request.result.Photo);
        } else {
            console.log("No more entries!");
        }
    };
}
