/**
 * Created by BALASUBRAMANIAM on 07-01-2015.
 */
/*
$(document).ready(function()
{
   $("button").click(function()
   {
       var x = $("#id").val();
       alert(x);
   });



});
*/
function Create()
{
    console.log("invoked");
    if(sessionStorage.getItem("id")==undefined)
    {


       var data=document.getElementById("id");
        var pwd=document.getElementById("password");
       sessionStorage.setItem("id",data.value);
        sessionStorage.setItem("pwd",pwd.value);
      window.open("ChangePassword.html");

    }


}

function ChangePwd()
{

    var oldpwd=document.getElementById("oldpassword");
    var newpwd=document.getElementById("newpassword");
    var resultref=document.getElementById("result");
    if(sessionStorage.getItem("pwd")!=undefined)
    {

        data=sessionStorage.getItem("pwd")

        if(oldpwd.value == data)
        {
            sessionStorage.setItem("pwd",newpwd.value);
            resultref.innerText="Password Changed";
        }


    }



}