/**
 * Created by BALASUBRAMANIAM on 08-01-2015.
 */

var worker = new Worker('scripts/runWorker.js');
worker.onmessage = function (e) {
    txt.innerHTML = e.data;
}
