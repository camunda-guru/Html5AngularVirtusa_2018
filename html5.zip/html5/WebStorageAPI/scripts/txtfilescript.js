/**
 * Created by BALASUBRAMANIAM on 08-01-2015.
 */

function DisplayFile()
{

    var fileref=document.getElementById("fname");
    var displayref=document.getElementById("displayarea");
    var filetype=/text.*/;
    console.log(fileref.files[0].type);
    if(fileref.files[0].type.match(filetype))
    {
        console.log("file type matching");
        //create reader object
        var reader=new FileReader();
        reader.onload=function(evt)
        {
          displayref.innerText=reader.result;
        };
        //read the content
        reader.readAsText(fileref.files[0]);

    }
    else
    {
        console.log("file type not matching");
    }


}