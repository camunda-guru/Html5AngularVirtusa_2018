/**
 * Created by BALASUBRAMANIAM on 27-12-2016.
 */
window.onload=test;
function test()
{
    if(window.sessionStorage.getItem("loginId")!=undefined)
    {
        console.log(window.sessionStorage.getItem("loginId"));
    }
}