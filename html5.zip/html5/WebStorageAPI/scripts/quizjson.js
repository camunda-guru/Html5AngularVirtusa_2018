/**
 * Created by BALASUBRAMANIAM on 16-09-2015.
 */
var dbref = window.indexedDB.open("CITIDB",2);
var db;
dbref.onerror = function(evt)
{
    console.log("Error Message"+evt.target.error);

};

dbref.onsuccess = function(evt)
{
    console.log(evt.target.result);
    db = dbref.result;
    console.log("Database Created");


};


dbref.onupgradeneeded=function(evt)
{
    db = evt.target.result;
    var objectStore = db.createObjectStore("QuizData", {keyPath: "QuestionNo"});
    console.log("Object Store Created");

};

function ReadData()
{

    var objectStore = db.transaction("QuizData").
        objectStore("QuizData");

    objectStore.openCursor().onsuccess = function(event) {
        var cursor = event.target.result;
        if (cursor) {
            console.log(JSON.stringify(event.target.result.value));
            //console.log("Question id " + cursor.key + " is " +
            //cursor.value.Question+cursor.value.Answer1+cursor.value.Answer2+cursor.value.Answer3+cursor.value.CorrectAnswer);
            cursor.continue();
        }
        else {
            console.log("No more entries!");
        }
    };




}