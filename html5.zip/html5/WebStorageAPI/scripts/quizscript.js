/**
 * Created by BALASUBRAMANIAM on 16-09-2015.
 */


var dbref = window.indexedDB.open("CITIDB",2);
var db;
dbref.onerror = function(evt)
{
    console.log("Error Message"+evt.target.error);

};

dbref.onsuccess = function(evt)
{
    console.log(evt.target.result);
    db = dbref.result;
    console.log("Database Created");


};


dbref.onupgradeneeded=function(evt)
{
    db = evt.target.result;
    var objectStore = db.createObjectStore("QuizData", {keyPath: "QuestionNo"});
    console.log("Object Store Created");

};


function AddQuestion()
{

    var questionid=document.getElementById("questionno");
    var ques = document.getElementById("question");

    var ans1 = document.getElementById("answer1");
    var ans2 = document.getElementById("answer2");
    var ans3 = document.getElementById("answer3");
    var correctans = document.getElementById("correctans");
    var request = db.transaction(["QuizData"], "readwrite")
        .objectStore("QuizData")
        .add({QuestionNo: questionid.value, Question:ques.value, Answer1:ans1.value,Answer2:ans2.value,Answer3:ans3.value, CorrectAnswer:correctans.value });

    request.onerror=function(evt)
    {
        console.log("Error Message"+evt.target.error);
    }
    request.onsuccess=function(evt)
    {
        console.log("Record added");
    }




}







